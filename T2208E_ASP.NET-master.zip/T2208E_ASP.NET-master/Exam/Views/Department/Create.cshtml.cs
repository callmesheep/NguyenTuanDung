using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Exam.Views.Department
{
    public class CreateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
