using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Exam.Views.Employee
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
